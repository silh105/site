<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Message extends Model {
    protected $fillable = ['chat_id', 'sender_id', 'text', 'is_read'];
    protected $casts = ['is_read' => 'boolean'];
    public function chat(): BelongsTo { return $this->belongsTo(Chat::class); }
    public function sender(): BelongsTo { return $this->belongsTo(User::class, 'sender_id'); }
}